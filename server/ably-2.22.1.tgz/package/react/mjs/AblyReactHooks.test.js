import { it, describe, expect } from 'vitest';
import { channelOptionsForReactHooks, version } from './AblyReactHooks.js';
describe('channelOptionsForReactHooks', () => {
    it('sets the react-hooks agent when no options are provided', () => {
        var _a;
        const options = channelOptionsForReactHooks();
        expect((_a = options.params) === null || _a === void 0 ? void 0 : _a.agent).toBe(`react-hooks/${version}`);
        expect(options.attachOnSubscribe).toBe(false);
    });
    it('sets the react-hooks agent when no agent is supplied', () => {
        var _a, _b;
        const options = channelOptionsForReactHooks({ params: { rewind: '1' } });
        expect((_a = options.params) === null || _a === void 0 ? void 0 : _a.agent).toBe(`react-hooks/${version}`);
        expect((_b = options.params) === null || _b === void 0 ? void 0 : _b.rewind).toBe('1');
    });
    it('appends the react-hooks agent to a caller-supplied agent instead of overwriting it', () => {
        var _a;
        const options = channelOptionsForReactHooks({ params: { agent: 'ai-transport-js/1.2.3' } });
        expect((_a = options.params) === null || _a === void 0 ? void 0 : _a.agent).toBe(`ai-transport-js/1.2.3 react-hooks/${version}`);
    });
    it('preserves other caller-supplied params and options alongside the merged agent', () => {
        var _a, _b;
        const options = channelOptionsForReactHooks({
            params: { agent: 'my-sdk/0.1.0', rewind: '5' },
            modes: ['presence', 'subscribe'],
        });
        expect((_a = options.params) === null || _a === void 0 ? void 0 : _a.agent).toBe(`my-sdk/0.1.0 react-hooks/${version}`);
        expect((_b = options.params) === null || _b === void 0 ? void 0 : _b.rewind).toBe('5');
        expect(options.modes).toEqual(['presence', 'subscribe']);
        expect(options.attachOnSubscribe).toBe(false);
    });
});
//# sourceMappingURL=AblyReactHooks.test.js.map