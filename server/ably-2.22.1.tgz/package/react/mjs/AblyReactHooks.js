export const version = '2.22.1';
/**
 * channel options for react-hooks
 */
export function channelOptionsForReactHooks(options) {
    var _a;
    const callerAgent = (_a = options === null || options === void 0 ? void 0 : options.params) === null || _a === void 0 ? void 0 : _a.agent;
    return Object.assign(Object.assign({}, options), { params: Object.assign(Object.assign({}, options === null || options === void 0 ? void 0 : options.params), { 
            // Append rather than overwrite a caller-supplied agent, so SDKs that layer
            // on top of the React hooks (e.g. @ably/ai-transport, @ably/chat) and pass
            // their own channel agent via ChannelProvider's `options` keep it for
            // attribution. Ably's agent param is a space-separated list of lib/version
            // tokens. A re-attach is not triggered by an agent-only change.
            agent: callerAgent ? `${callerAgent} react-hooks/${version}` : `react-hooks/${version}` }), 
        // we explicitly attach channels in React hooks (useChannel, usePresence, usePresenceListener)
        // to avoid situations where implicit attachment could cause errors (when connection state is failed or disconnected)
        attachOnSubscribe: false });
}
//# sourceMappingURL=AblyReactHooks.js.map