export const INACTIVE_CONNECTION_STATES = ['suspended', 'closing', 'closed', 'failed'];
export const INACTIVE_CHANNEL_STATES = ['failed', 'suspended', 'detaching'];
//# sourceMappingURL=constants.js.map