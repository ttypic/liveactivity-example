import type * as Ably from 'ably';
export declare const INACTIVE_CONNECTION_STATES: Ably.ConnectionState[];
export declare const INACTIVE_CHANNEL_STATES: Ably.ChannelState[];
